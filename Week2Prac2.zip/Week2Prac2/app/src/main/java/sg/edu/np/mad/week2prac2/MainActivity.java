package sg.edu.np.mad.week2prac2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button controlbutton = findViewById(R.id.followbutton);
        User myObj = new User();
        controlbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (myObj.followed == true){
                    controlbutton.setText("UNFOLLOW");
                    myObj.setFollowed(false);
                }
                else{
                    controlbutton.setText("FOLLOW");
                    myObj.setFollowed(true);
                };
            }
        });
    }
}

